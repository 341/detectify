import React, {Component} from 'react';

class Index extends Component {

    state = {
        // states here
    };

    render () {

        return (
            <div>
                NoItems
            </div>
        )

    }
}

export default Index;