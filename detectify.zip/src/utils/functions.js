export const has = (array) => {
    return Array.isArray(array) && array.length > 0;
};